# Integración conceptual con GraphQL y gRPC

La API REST de FitControl (contrato en `openapi.yaml`) es la **fuente de verdad**. GraphQL y gRPC no
la reemplazan: se apoyan en ella para resolver necesidades que REST cubre peor.

## 1. GraphQL — capa BFF para el frontend

**Problema:** para pintar la ficha de un cliente el frontend hace 3 llamadas REST
(`/api/clientes/{id}`, `/api/membresias`, `/api/planes`) y filtra datos que no necesita (*over-fetching*).

**Solución conceptual:** un servicio BFF (Backend For Frontend) expone un único endpoint `/graphql`
cuyos *resolvers* llaman a los endpoints REST existentes.

```graphql
type Cliente {
  id_cliente: ID!
  nombre: String!
  apellido: String!
  estado: EstadoCliente!
  membresias: [Membresia!]!
}
type Membresia { id: ID!  plan: String!  fecha_inicio: String!  fecha_fin: String!  estado: String! }
enum EstadoCliente { Activo Inactivo }

type Query {
  clientes(estado: EstadoCliente, q: String): [Cliente!]!   # GET /api/clientes
  cliente(id: ID!): Cliente                                  # GET /api/clientes/{id}
}
type Mutation {
  crearCliente(nombre: String!, apellido: String!, estado: EstadoCliente = Activo): Cliente!  # POST /api/clientes
}
```

| REST (contrato OpenAPI) | GraphQL |
|---|---|
| `Authorization: Bearer <token>` | Mismo encabezado; el BFF lo reenvía a la API |
| `application/problem+json` (RFC 9457) | `errors[].extensions` = `{ type, title, status, detail }` |
| `errors[]` de validación `{campo, mensaje}` | `extensions.errors` |

## 2. gRPC — comunicación interna entre microservicios

**Escenario:** un futuro servicio de *facturación* necesita consultar clientes y membresías de forma
rápida y fuertemente tipada, sin pasar por HTTP/JSON público.

```proto
syntax = "proto3";
package fitcontrol.v1;

service ClienteService {
  rpc ObtenerCliente (ObtenerClienteRequest) returns (Cliente);
  rpc ListarClientes (ListarClientesRequest) returns (ListarClientesResponse);
}
message ObtenerClienteRequest { int32 id_cliente = 1; }
message ListarClientesRequest { string estado = 1; string q = 2; }
message ListarClientesResponse { repeated Cliente clientes = 1; }
message Cliente {
  int32 id_cliente = 1;
  string nombre = 2;
  string apellido = 3;
  string telefono = 4;
  string direccion = 5;
  string estado = 6;
}
```

**Mapeo de errores HTTP (Problem Details) a estados gRPC**

| HTTP | gRPC |
|---|---|
| 400 | `INVALID_ARGUMENT` |
| 401 | `UNAUTHENTICATED` |
| 403 | `PERMISSION_DENIED` |
| 404 | `NOT_FOUND` |
| 409 | `ALREADY_EXISTS` / `ABORTED` |
| 422 | `FAILED_PRECONDITION` |
| 500 | `INTERNAL` |

## 3. Cuándo usar cada uno

| Necesidad | Tecnología |
|---|---|
| API pública, simple, cacheable, documentada con OpenAPI | **REST** (lo implementado) |
| Frontend que combina varias entidades y quiere pedir solo algunos campos | **GraphQL** (BFF) |
| Llamadas internas de alto rendimiento entre servicios | **gRPC** |
